# 推箱子

**jdk版本为：JDK1.8**

**开发工具为：Eclipse**

**Java**

我的blog地址：
[My Blog](http://blog.csdn.net/divide_)


将文件导入eclips中，运行App.java文件即可；

大神勿喷~~